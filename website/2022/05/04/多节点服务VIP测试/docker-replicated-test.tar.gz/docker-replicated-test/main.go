package main

import (
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"time"
)

var (
	HOSTNAME string = "UNKNOW"
)

func init() {
	name, err := os.Hostname()
	if err != nil {
		name = err.Error()
	}
	HOSTNAME = name
}

func main() {
	mux := http.NewServeMux()
	mux.Handle("/", http.StripPrefix("/", handler{}))

	server := &http.Server{
		Addr:    "0.0.0.0:8080",
		Handler: mux,
	}
	log.Printf("server Running at http://%v\n", server.Addr)

	server.ListenAndServe()
}

type handler struct{}

func (h handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	start := time.Now()

	w.Write([]byte(HOSTNAME + ":\t" + time.Now().Format("2006-01-02 15:04:05")))

	requestsURL, _ := url.QueryUnescape(r.RequestURI)
	fmt.Printf("%v ---> %v %v %s ", r.RemoteAddr, r.Proto, r.Method, requestsURL)
	fmt.Println(time.Since(start))

	w.Write([]byte("\t<<< " + requestsURL))
}
