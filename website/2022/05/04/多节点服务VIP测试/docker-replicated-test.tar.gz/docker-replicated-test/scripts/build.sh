#!/bin/bash --posix

echo "making server"

go build -tags netgo                                \
    -installsuffix 'static'                         \
    -ldflags "                                      \
    -s -w                                           \
    "                                               \
    -o server main.go
