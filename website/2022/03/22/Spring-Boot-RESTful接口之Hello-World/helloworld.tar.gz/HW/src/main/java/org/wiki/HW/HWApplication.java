package org.wiki.HW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HWApplication {

	public static void main(String[] args) {
		SpringApplication.run(HWApplication.class, args);
	}
}
