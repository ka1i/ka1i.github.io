﻿// WindowsProject1.cpp : 定义应用程序的入口点。
//

#include "framework.h"


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow) {
	MessageBox(NULL, TEXT("Hello windows,are you there?"), TEXT("Hello world"), 1);
	return 0;
}